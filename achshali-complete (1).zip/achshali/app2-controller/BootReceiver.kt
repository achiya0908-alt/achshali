package com.achshali.controller

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Controller לא צריך service - הוא מגיב רק ל-broadcasts
        // אין צורך להפעיל שום דבר באתחול
    }
}
