package com.achshali.controller

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telephony.SmsManager
import android.util.Log
import androidx.core.content.ContextCompat

/**
 * הלב של אפליקציה 2
 * מקבל broadcast מאפליקציה 1 ומבצע כל פעולה
 */
class PhoneActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "com.achshali.EXECUTE_ACTION") return

        val action = intent.getStringExtra("action") ?: return
        val target = intent.getStringExtra("target") ?: ""
        val message = intent.getStringExtra("message") ?: ""

        Log.d("Achshali", "Action: $action | Target: $target | Message: $message")

        val result = when (action.uppercase()) {
            "CALL" -> makeCall(context, target)
            "SMS" -> sendSMS(context, target, message)
            "OPEN_APP" -> openApp(context, target)
            "SEARCH" -> openSearch(context, target)
            "ALARM" -> setAlarm(context, target)
            "WHATSAPP" -> openWhatsApp(context, target, message)
            "NAVIGATE" -> openNavigation(context, target)
            "EMAIL" -> openEmail(context, target, message)
            else -> "פעולה לא מוכרת: $action"
        }

        // שלח תוצאה חזרה לאפליקציה 1
        val resultIntent = Intent("com.achshali.ACTION_RESULT").apply {
            setPackage("com.achshali.brain")
            putExtra("action", action)
            putExtra("result", result)
        }
        context.sendBroadcast(resultIntent)
    }

    // ==========================================
    // 📞 ביצוע שיחת טלפון
    // ==========================================
    private fun makeCall(context: Context, target: String): String {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED) {
            return "אין הרשאה לבצע שיחות"
        }

        val phoneNumber = resolveContact(context, target)
        if (phoneNumber == null) {
            return "לא מצאתי את $target באנשי הקשר"
        }

        val callIntent = Intent(Intent.ACTION_CALL).apply {
            data = Uri.parse("tel:$phoneNumber")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(callIntent)
        return "מתקשר ל$target ($phoneNumber)"
    }

    // ==========================================
    // 📱 שליחת SMS
    // ==========================================
    private fun sendSMS(context: Context, target: String, message: String): String {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            return "אין הרשאה לשלוח SMS"
        }

        val phoneNumber = resolveContact(context, target)
        if (phoneNumber == null) {
            return "לא מצאתי את $target באנשי הקשר"
        }

        return try {
            val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            "הודעה נשלחה ל$target"
        } catch (e: Exception) {
            "שגיאה בשליחת הודעה: ${e.message}"
        }
    }

    // ==========================================
    // 📲 פתיחת אפליקציה
    // ==========================================
    private fun openApp(context: Context, appName: String): String {
        val packageName = getPackageByName(appName)

        return if (packageName != null) {
            try {
                val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
                if (launchIntent != null) {
                    launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    context.startActivity(launchIntent)
                    "פתחתי את $appName"
                } else {
                    "לא הצלחתי לפתוח את $appName"
                }
            } catch (e: Exception) {
                "שגיאה: ${e.message}"
            }
        } else {
            // נסה למצוא לפי שם חבילה ישיר
            "לא מצאתי אפליקציה בשם $appName"
        }
    }

    // ==========================================
    // 🔍 פתיחת חיפוש
    // ==========================================
    private fun openSearch(context: Context, query: String): String {
        val searchIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra("query", query)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return try {
            context.startActivity(searchIntent)
            "מחפש: $query"
        } catch (e: Exception) {
            val browserIntent = Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")
            ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
            context.startActivity(browserIntent)
            "פתחתי חיפוש: $query"
        }
    }

    // ==========================================
    // ⏰ קביעת שעון מעורר
    // ==========================================
    private fun setAlarm(context: Context, timeStr: String): String {
        // ניתוח שעה מהמלל
        val hour = extractHour(timeStr)
        val minute = extractMinute(timeStr)

        val alarmIntent = Intent("android.intent.action.SET_ALARM").apply {
            putExtra("android.intent.extra.alarm.HOUR", hour)
            putExtra("android.intent.extra.alarm.MINUTES", minute)
            putExtra("android.intent.extra.alarm.MESSAGE", "אחשלי - תזכורת")
            putExtra("android.intent.extra.alarm.SKIP_UI", true)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        return try {
            context.startActivity(alarmIntent)
            "קבעתי שעון מעורר ל-$hour:${minute.toString().padStart(2, '0')}"
        } catch (e: Exception) {
            "שגיאה בקביעת שעון מעורר"
        }
    }

    // ==========================================
    // 💬 פתיחת WhatsApp
    // ==========================================
    private fun openWhatsApp(context: Context, target: String, message: String): String {
        val phoneNumber = resolveContact(context, target)

        return try {
            val intent = if (phoneNumber != null && message.isNotEmpty()) {
                // שלח הודעה ספציפית
                val cleanNumber = phoneNumber.replace("+", "").replace("-", "").replace(" ", "")
                Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://wa.me/$cleanNumber?text=${Uri.encode(message)}")
                )
            } else {
                // פתח WhatsApp סתם
                context.packageManager.getLaunchIntentForPackage("com.whatsapp")
                    ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"))
            }
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
            if (phoneNumber != null) "פתחתי WhatsApp עם $target" else "פתחתי WhatsApp"
        } catch (e: Exception) {
            "לא הצלחתי לפתוח WhatsApp"
        }
    }

    // ==========================================
    // 🗺️ ניווט
    // ==========================================
    private fun openNavigation(context: Context, destination: String): String {
        val mapsIntent = Intent(Intent.ACTION_VIEW,
            Uri.parse("google.navigation:q=${Uri.encode(destination)}")
        ).apply {
            setPackage("com.google.android.apps.maps")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        return try {
            context.startActivity(mapsIntent)
            "פותח ניווט ל$destination"
        } catch (e: Exception) {
            val browserIntent = Intent(Intent.ACTION_VIEW,
                Uri.parse("https://maps.google.com/?q=${Uri.encode(destination)}")
            ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
            context.startActivity(browserIntent)
            "פותח מפה ל$destination"
        }
    }

    // ==========================================
    // 📧 פתיחת אימייל
    // ==========================================
    private fun openEmail(context: Context, to: String, subject: String): String {
        val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:$to")
            putExtra(Intent.EXTRA_SUBJECT, subject)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return try {
            context.startActivity(emailIntent)
            "פתחתי אימייל חדש"
        } catch (e: Exception) {
            "שגיאה בפתיחת אימייל"
        }
    }

    // ==========================================
    // 🔍 עזר - מציאת מספר מאנשי קשר
    // ==========================================
    private fun resolveContact(context: Context, name: String): String? {
        // תחילה נסה כמספר ישיר
        if (name.matches(Regex("[0-9+\\-\\s()]+"))) {
            return name
        }

        // חפש באנשי קשר
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            return null
        }

        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )

        cursor?.use {
            if (it.moveToFirst()) {
                return it.getString(it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER))
            }
        }
        return null
    }

    // ==========================================
    // 📱 מיפוי שמות אפליקציות לחבילות
    // ==========================================
    private fun getPackageByName(name: String): String? {
        val appMap = mapOf(
            "וואטסאפ" to "com.whatsapp",
            "whatsapp" to "com.whatsapp",
            "יוטיוב" to "com.google.android.youtube",
            "youtube" to "com.google.android.youtube",
            "גוגל" to "com.google.android.googlequicksearchbox",
            "google" to "com.google.android.googlequicksearchbox",
            "פייסבוק" to "com.facebook.katana",
            "facebook" to "com.facebook.katana",
            "אינסטגרם" to "com.instagram.android",
            "instagram" to "com.instagram.android",
            "טיקטוק" to "com.zhiliaoapp.musically",
            "tiktok" to "com.zhiliaoapp.musically",
            "טלגרם" to "org.telegram.messenger",
            "telegram" to "org.telegram.messenger",
            "מפות" to "com.google.android.apps.maps",
            "maps" to "com.google.android.apps.maps",
            "מצלמה" to "com.android.camera2",
            "camera" to "com.android.camera2",
            "גלריה" to "com.google.android.apps.photos",
            "gallery" to "com.google.android.apps.photos",
            "ספוטיפיי" to "com.spotify.music",
            "spotify" to "com.spotify.music",
            "נטפליקס" to "com.netflix.mediaclient",
            "netflix" to "com.netflix.mediaclient",
            "קלים" to "com.waze",
            "ווייז" to "com.waze",
            "waze" to "com.waze",
            "לינקדאין" to "com.linkedin.android",
            "linkedin" to "com.linkedin.android",
            "גמייל" to "com.google.android.gm",
            "gmail" to "com.google.android.gm",
            "כרום" to "com.android.chrome",
            "chrome" to "com.android.chrome",
            "שעון" to "com.google.android.deskclock",
            "clock" to "com.google.android.deskclock",
            "מחשבון" to "com.google.android.calculator",
            "calculator" to "com.google.android.calculator",
            "הגדרות" to "com.android.settings",
            "settings" to "com.android.settings"
        )

        val lowerName = name.lowercase()
        return appMap.entries.firstOrNull { lowerName.contains(it.key) }?.value
    }

    // ==========================================
    // ⏰ ניתוח שעות מטקסט
    // ==========================================
    private fun extractHour(text: String): Int {
        val patterns = listOf(
            Regex("(\\d{1,2}):(\\d{2})"),
            Regex("(\\d{1,2}) בבוקר"),
            Regex("(\\d{1,2}) בערב"),
            Regex("שעה (\\d{1,2})")
        )

        for (pattern in patterns) {
            val match = pattern.find(text)
            if (match != null) {
                return match.groupValues[1].toIntOrNull() ?: 8
            }
        }
        return 8 // ברירת מחדל
    }

    private fun extractMinute(text: String): Int {
        val pattern = Regex("(\\d{1,2}):(\\d{2})")
        val match = pattern.find(text)
        return match?.groupValues?.get(2)?.toIntOrNull() ?: 0
    }
}
