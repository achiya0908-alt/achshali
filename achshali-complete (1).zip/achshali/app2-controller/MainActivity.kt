package com.achshali.controller

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.telephony.SmsManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

/**
 * אפליקציה 2 - Phone Controller
 * מקבלת פקודות מאפליקציה 1 ומבצעת פעולות טלפון אמיתיות
 */
class MainActivity : AppCompatActivity() {

    private lateinit var logText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_controller)

        logText = findViewById(R.id.logText)
        requestAllPermissions()

        // רישום Broadcast Receiver
        val receiver = PhoneActionReceiver()
        val filter = IntentFilter("com.achshali.EXECUTE_ACTION")
        registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)

        logText.text = "✅ אחשלי Controller פעיל\nממתין לפקודות מהמוח..."
        
        // הצג למשתמש שהאפליקציה עובדת
        Toast.makeText(this, "אחשלי Controller מוכן!", Toast.LENGTH_SHORT).show()
    }

    private fun requestAllPermissions() {
        ActivityCompat.requestPermissions(this, arrayOf(
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.WRITE_CONTACTS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.READ_CALL_LOG
        ), 100)
    }
}
