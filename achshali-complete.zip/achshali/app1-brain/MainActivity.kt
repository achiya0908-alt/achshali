package com.achshali.brain

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.speech.*
import android.speech.tts.*
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech // גיבוי אם ElevenLabs נכשל
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false
    private var wakeWordMode = false

    // API Keys
    private val CLAUDE_API_KEY = "YOUR_CLAUDE_API_KEY_HERE"
    private val ELEVENLABS_API_KEY = "sk_4ad95f859e712325e02fb65123b1e65a0b54095eef2da1b9"
    private val ELEVENLABS_VOICE_ID = "pf7e37SC3G5vewpfrFON"
    private val CONTROLLER_PACKAGE = "com.achshali.controller"

    // UI Elements
    private lateinit var statusText: TextView
    private lateinit var responseText: TextView
    private lateinit var listenButton: ImageButton
    private lateinit var wakeWordSwitch: android.widget.Switch
    private lateinit var inputEditText: EditText
    private lateinit var sendTextButton: Button
    private lateinit var visualizer: View

    private val conversationHistory = mutableListOf<JSONObject>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tts = TextToSpeech(this, this)
        setupUI()
        requestPermissions()
        setupWakeWordListener()

        // אם הופעלנו מקיצור דרך
        if (intent?.action == "com.achshali.QUICK_LAUNCH") {
            startListening()
        }
    }

    private fun setupUI() {
        statusText = findViewById(R.id.statusText)
        responseText = findViewById(R.id.responseText)
        listenButton = findViewById(R.id.listenButton)
        wakeWordSwitch = findViewById(R.id.wakeWordSwitch)
        inputEditText = findViewById(R.id.inputEditText)
        sendTextButton = findViewById(R.id.sendTextButton)
        visualizer = findViewById(R.id.visualizer)

        listenButton.setOnClickListener {
            if (isListening) stopListening() else startListening()
        }

        wakeWordSwitch.setOnCheckedChangeListener { _, isChecked ->
            wakeWordMode = isChecked
            if (isChecked) {
                statusText.text = "ממתין לפקודה... אמור 'אחשלי'"
                startWakeWordListening()
            } else {
                stopListening()
                statusText.text = "לחץ על המיקרופון או אמור 'אחשלי'"
            }
        }

        sendTextButton.setOnClickListener {
            val text = inputEditText.text.toString().trim()
            if (text.isNotEmpty()) {
                processCommand(text)
                inputEditText.setText("")
            }
        }
    }

    private fun setupWakeWordListener() {
        // Broadcast receiver לקבלת פקודות מאפליקציית השליטה
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val result = intent.getStringExtra("result") ?: return
                val action = intent.getStringExtra("action") ?: return
                responseText.text = "✅ $action בוצע: $result"
                speak("בוצע: $result")
            }
        }
        val filter = IntentFilter("com.achshali.ACTION_RESULT")
        registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
    }

    private fun startWakeWordListening() {
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle) {
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()?.lowercase() ?: ""
                if (text.contains("אחשלי")) {
                    wakeWordDetected()
                } else if (wakeWordMode && !isListening) {
                    // המשך להאזין
                    Handler(Looper.getMainLooper()).postDelayed({
                        if (wakeWordMode) startWakeWordListening()
                    }, 500)
                }
            }
            override fun onError(error: Int) {
                if (wakeWordMode && !isListening) {
                    Handler(Looper.getMainLooper()).postDelayed({
                        if (wakeWordMode) startWakeWordListening()
                    }, 1000)
                }
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "he-IL")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        speechRecognizer?.startListening(intent)
    }

    private fun wakeWordDetected() {
        isListening = true
        statusText.text = "🎤 אחשלי מקשיב... מה תרצה?"
        visualizer.visibility = View.VISIBLE
        speak("כן? במה אני יכול לעזור?") {
            startCommandListening()
        }
    }

    private fun startCommandListening() {
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle) {
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull() ?: ""
                if (text.isNotEmpty()) {
                    isListening = false
                    visualizer.visibility = View.GONE
                    processCommand(text)
                }
            }
            override fun onError(error: Int) {
                isListening = false
                visualizer.visibility = View.GONE
                statusText.text = "לא הצלחתי לשמוע, נסה שוב"
                if (wakeWordMode) startWakeWordListening()
            }
            override fun onReadyForSpeech(params: Bundle?) { statusText.text = "🎤 מקשיב..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { statusText.text = "מעבד..." }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "he-IL")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        speechRecognizer?.startListening(intent)
    }

    fun startListening() {
        isListening = true
        listenButton.setImageResource(android.R.drawable.ic_media_pause)
        wakeWordDetected()
    }

    fun stopListening() {
        isListening = false
        speechRecognizer?.stopListening()
        listenButton.setImageResource(android.R.drawable.ic_btn_speak_now)
        visualizer.visibility = View.GONE
        statusText.text = "לחץ על המיקרופון או אמור 'אחשלי'"
    }

    private fun processCommand(command: String) {
        statusText.text = "מעבד: \"$command\""
        responseText.text = "⏳ אחשלי חושב..."

        val systemPrompt = """
        אתה אחשלי - עוזר קולי חכם ומגניב. אתה מדבר בסגנון ערסי ישראלי - אחי, יאללה, וואלה, סבבה, קלאס, נו באסה, יאני וכו'.
        אתה תמיד מגניב, קצר ולעניין. לא מסביר יותר מדי. כמו חבר שיודע הכל.
        
        אם המשתמש דיבר אליך בעברית - ענה בעברית בסגנון ערסי.
        אם המשתמש דיבר אליך באנגלית - ענה באנגלית אבל עם מבטא ישראלי מזרחי כבד בכתיב:
        במקום "the" כתוב "ze", במקום "this" כתוב "zis", 
        במקום "th" בכלל כתוב "z", h בהתחלת מילה לפעמים נשמט,
        הוסף "walla", "yalla", "sababa", "achiii" במשפטים באנגלית.
        
        דוגמאות בעברית:
        - "יאללה אחי, מתקשר לאמא שלך עכשיו, סבבה?"
        - "וואלה עשיתי את זה כבר אחי, קלאס!"
        - "יאני מה בדיוק תרצה ממני אחי?"
        - "נו באסה, לא מצאתי את המספר אחי"
        - "סבבה אחי, פתחתי לך את וואטסאפ, קדימה"
        
        דוגמאות באנגלית עם מבטא:
        - "Yalla achi, I em calling your ima right now, sababa?"
        - "Walla I deed it already achi, klас!"
        - "Ze number is not in ze contacts achi, nu baasa"
        - "Ok achi I opened ze whatsapp for you, yalla"
        
        אם הפקודה היא פעולת טלפון, ענה ONLY עם JSON כזה:
        {
          "action": "CALL" | "SMS" | "OPEN_APP" | "SEARCH" | "ALARM" | "ANSWER",
          "target": "שם איש הקשר / מספר / שם אפליקציה",
          "message": "תוכן ההודעה אם רלוונטי",
          "speech": "מה להגיד בסגנון ערסי"
        }
        
        פעולות אפשריות:
        - CALL: "תתקשר לאמא", "חייג ל...", "התקשר ל..."
        - SMS: "שלח הודעה ל...", "כתוב ל..."  
        - OPEN_APP: "פתח וואטסאפ", "תפתח..."
        - SEARCH: "חפש ב...", "מה זה..."
        - ALARM: "העלה שעון מעורר ל...", "תזכיר לי..."
        - ANSWER: שאלות רגילות - ענה בסגנון ערסי (לא JSON)
        
        תמיד קצר, תמיד מגניב, תמיד ערסי!
        """.trimIndent()

        conversationHistory.add(JSONObject().apply {
            put("role", "user")
            put("content", command)
        })

        val requestBody = JSONObject().apply {
            put("model", "claude-sonnet-4-20250514")
            put("max_tokens", 500)
            put("system", systemPrompt)
            put("messages", JSONArray(conversationHistory.map { it.toString() }))
        }

        val client = OkHttpClient()
        val request = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("x-api-key", CLAUDE_API_KEY)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(requestBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string() ?: return
                runOnUiThread {
                    try {
                        val json = JSONObject(body)
                        val content = json.getJSONArray("content").getJSONObject(0).getString("text")
                        
                        conversationHistory.add(JSONObject().apply {
                            put("role", "assistant")
                            put("content", content)
                        })

                        // נסה לפרסר כ-JSON (פקודת טלפון)
                        try {
                            val cmd = JSONObject(content.trim())
                            val action = cmd.getString("action")
                            val target = cmd.optString("target", "")
                            val message = cmd.optString("message", "")
                            val speech = cmd.optString("speech", "מבצע פעולה...")

                            responseText.text = "📱 $action → $target"
                            speak(speech)
                            sendToController(action, target, message)

                        } catch (e: Exception) {
                            // תשובה רגילה
                            responseText.text = content
                            speak(content)
                        }

                    } catch (e: Exception) {
                        statusText.text = "שגיאה בעיבוד התשובה"
                    }

                    if (wakeWordMode) {
                        Handler(Looper.getMainLooper()).postDelayed({
                            startWakeWordListening()
                        }, 2000)
                    }
                }
            }

            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    statusText.text = "שגיאת רשת - בדוק חיבור אינטרנט"
                }
            }
        })
    }

    private fun sendToController(action: String, target: String, message: String) {
        val intent = Intent("com.achshali.EXECUTE_ACTION").apply {
            setPackage(CONTROLLER_PACKAGE)
            putExtra("action", action)
            putExtra("target", target)
            putExtra("message", message)
        }
        sendBroadcast(intent)
    }

    private fun speak(text: String, onDone: (() -> Unit)? = null) {
        val requestBody = JSONObject().apply {
            put("text", text)
            put("model_id", "eleven_multilingual_v2")
            put("voice_settings", JSONObject().apply {
                put("stability", 0.5)
                put("similarity_boost", 0.85)
                put("style", 0.3)
                put("use_speaker_boost", true)
            })
        }

        val client = OkHttpClient()
        val request = Request.Builder()
            .url("https://api.elevenlabs.io/v1/text-to-speech/$ELEVENLABS_VOICE_ID")
            .addHeader("xi-api-key", ELEVENLABS_API_KEY)
            .addHeader("Content-Type", "application/json")
            .addHeader("Accept", "audio/mpeg")
            .post(requestBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    val audioBytes = response.body?.bytes() ?: return
                    val tempFile = java.io.File(cacheDir, "achshali_speech.mp3")
                    tempFile.writeBytes(audioBytes)
                    val mediaPlayer = android.media.MediaPlayer()
                    mediaPlayer.setDataSource(tempFile.absolutePath)
                    mediaPlayer.prepare()
                    mediaPlayer.setOnCompletionListener {
                        it.release()
                        tempFile.delete()
                        onDone?.invoke()
                    }
                    mediaPlayer.start()
                } else {
                    runOnUiThread { fallbackSpeak(text, onDone) }
                }
            }
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { fallbackSpeak(text, onDone) }
            }
        })
    }

    private fun fallbackSpeak(text: String, onDone: (() -> Unit)? = null) {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onDone(utteranceId: String?) { onDone?.invoke() }
            override fun onError(utteranceId: String?) {}
            override fun onStart(utteranceId: String?) {}
        })
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "achshali_speak")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = java.util.Locale("he", "IL")
            statusText.text = "אחשלי מוכן! לחץ על המיקרופון או אמור 'אחשלי'"
        }
    }

    private fun requestPermissions() {
        val permissions = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.SEND_SMS
        )
        ActivityCompat.requestPermissions(this, permissions, 1)
    }

    override fun onDestroy() {
        tts.shutdown()
        speechRecognizer?.destroy()
        super.onDestroy()
    }
}
